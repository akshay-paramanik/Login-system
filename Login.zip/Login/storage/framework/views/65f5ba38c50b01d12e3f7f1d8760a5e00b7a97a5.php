<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <a href="/">Back</a>
    <form action="/update/<?php echo e($data->id); ?>" method="post">
        <?php echo e(csrf_field()); ?>

        <input type="text" name="name" value="<?php echo e($data->name); ?>"><br>
        <input type="text" name="age" value="<?php echo e($data->age); ?>"><br>
        <input type="submit" value="Save">
    </form>
</body>
</html><?php /**PATH C:\Users\Lab1-3.Server-PC\Desktop\Task\resources\views/edit.blade.php ENDPATH**/ ?>