<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>
    <link href="<?php echo e(asset('css/register.css')); ?>" rel="stylesheet">
</head>
<body>
    <div class="container">
    <div class="main">
        <div class="sign-in">
        <form action="login" method="post">
            <?php echo csrf_field(); ?>
                <h1>Login</h1>
                <p>Login with currect information</p>
                <label for="email"><b>Email</b></label>
                <input type="text" placeholder="Enter Email" name="email" id="email" required>
                <label for="psw"><b>Password</b></label>
                <input type="password" placeholder="Enter Password" name="password" id="psw" required>
                <input type="checkbox" name="showpassword" onclick="ckeck()" id="show"><span>show password</span><br>
    
                <input type="submit" class="registerbtn" value="Register" name="register">
    
            <div class="signin">
                <p> <a href="<?php echo e(url('register')); ?>">Create new account</a>.</p>
            </div>
        </form>
        </div>
    </div>
    </div>
    <script src="<?php echo e(asset('js/script.js')); ?>"></script>
</body>
</html><?php /**PATH D:\Task\Login\resources\views/login.blade.php ENDPATH**/ ?>