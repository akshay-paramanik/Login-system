<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
    <link href="{{ asset('css/register.css') }}" rel="stylesheet">
</head>
<body>
    <div class="container">
    <div class="main">
        <div class="sign-in">
        <form action="register" method="post">
            @csrf
                <h1>Register</h1>
                <p>Please fill in this form to create an account.</p>
                <label for="fname"><b>Full Name</b></label>
                <input type="text" placeholder="Enter full name" name="name" id="fname" required>
                <span>
                    @error('name')
                    {{$message}}
                    @enderror
                </span>
                <label for="email"><b>Email</b></label>
                <input type="text" placeholder="Enter Email" name="email" id="email" required>
                <span>
                    @error('email')
                    {{$message}}
                    @enderror
                </span>
                <label for="psw"><b>Password</b></label>
                <input type="password" placeholder="Enter Password" name="password" id="psw" required>
                <span>
                    @error('password')
                    {{$message}}
                    @enderror
                </span>
                
                <label for="pin"><b>Confirm Password</b></label>
                <input type="password" placeholder="Re enter your password" name="password_confirmation" id="psw-repeat" required>
                <span>
                    @error('password_confirmation')
                    {{$message}}
                    @enderror
                </span>
                <input type="checkbox" name="showpassword" onclick="ckeck()" id="show"><span>show password</span><br>
    
                <input type="submit" class="registerbtn" value="Register" name="register">
    
            <div class="signin">
                <p>Already have an account? <a href="{{url('/')}}">LogIn</a>.</p>
            </div>
        </form>
        </div>
    </div>
    </div>
    <script src="{{ asset('js/script.js') }}"></script>
</body>
</html>