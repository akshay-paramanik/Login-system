let show = document.getElementById("show");
function ckeck() {
    var password = document.getElementById("psw");
    var rePassword = document.getElementById("psw-repeat");
    if (password.type == "password") {
        password.type = "text";
    } else {
        password.type = "password";
    }
    if (rePassword.type == "password") {
        rePassword.type = "text";
    } else {
        rePassword.type = "password";
    }
}
