<?php

namespace App\Http\Controllers;

use App\Models\loginUser;
use Illuminate\Http\Request;

class userauth extends Controller
{
    public function store(Request $request){
        $request->validate([
            'name' => 'required',
            'email' => 'required|email|unique:user',
            'password' => 'required|min:8|confirmed',
            'password_confirmation' => 'required'
        ]);
        // if($request->psw !== $request->confirm){
        //     return redirect()->back();
        // }
        $name = $request->name;
        $email = $request->email;
        $password = $request->password;
        $encpassword = bcrypt($password);
                $insert = new loginUser();
                $insert->name = $name;
                $insert->email = $email;
                $insert->password = $encpassword;
                $insert->save();
                session()->put('username',$name);
                return redirect('/dashbord');
        
    }
    public function login(Request $request){
        $email = $request->email;
        $password = $request->password;
        $user = loginUser::where('email',$email)->first();
        if($user){
            if(password_verify($password,$user->password)){
                session()->put('username',$user->name);
                return redirect('/dashbord');
            }else{
                return "Unauthorized access";
            }
        }else{
            return "user not found";
        }
    }
    public function delete(){
        session()->forget('username');
        return redirect('/');
    }
}
